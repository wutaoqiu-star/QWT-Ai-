using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Input;
using QuickLook.Plugin.FbxViewer;

internal static class SmokeTests
{
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            Console.WriteLine("Fixtures: " + String.Join(" | ", args));
            var plugin = new Plugin();
            Check(ModelView.IsWireframeShortcut(Key.System, Key.W, ModifierKeys.Alt), "Alt+W SystemKey not recognized");
            Check(ModelView.IsWireframeShortcut(Key.W, Key.None, ModifierKeys.Alt), "Alt+W regular key not recognized");
            Check(!ModelView.IsWireframeShortcut(Key.W, Key.None, ModifierKeys.None), "Plain W should not toggle wireframe");
            Console.WriteLine("PASS Alt+W regular and WPF SystemKey handling");
            Check(!plugin.CanHandle("missing.fbx"), "Nonexistent file accepted");
            Check(!plugin.CanHandle(Path.GetDirectoryName(args[0])), "Directory accepted");
            Check(plugin.CanHandle(args[0]), "FBX not recognized");
            Directory.CreateDirectory("中文目录");
            File.Copy(args[0], Path.Combine("中文目录", "房间.fbx"), true);
            var unicodeResult = ModelLoader.Load(Path.GetFullPath(Path.Combine("中文目录", "房间.fbx")), CancellationToken.None);
            Check(unicodeResult.Meshes > 0 && unicodeResult.Triangles > 0, "Unicode path import failed");
            Console.WriteLine("PASS Unicode path import: 中文目录\\房间.fbx");
            File.Copy(args[0], "uppercase.FBX", true);
            Check(plugin.CanHandle(Path.GetFullPath("uppercase.FBX")), "Uppercase extension rejected");
            File.WriteAllText("broken.fbx", "not an FBX file");
            bool rejected = false;
            try { ModelLoader.Load(Path.GetFullPath("broken.fbx"), CancellationToken.None); }
            catch (Exception) { rejected = true; }
            Check(rejected, "Corrupt file accepted");
            Console.WriteLine("PASS file detection and corrupt file rejection");
            var canceled = new CancellationTokenSource(); canceled.Cancel();
            try { ModelLoader.Load(args[0], canceled.Token); throw new Exception("Cancellation ignored"); }
            catch (OperationCanceledException) { Console.WriteLine("PASS cancellation"); }
            ModelResult first = null;
            foreach (string fixture in args)
            {
                var result = ModelLoader.Load(fixture, CancellationToken.None);
                Check(result.Triangles > 0 && result.Meshes > 0, "Empty model");
                Check(result.Model.IsFrozen, "Model cannot cross thread boundary");
                Check(result.Appearances.Count == result.Meshes, "Material channel metadata mismatch");
                foreach (var appearance in result.Appearances)
                    Check(appearance.Diffuse.IsFrozen && appearance.Metalness.IsFrozen && appearance.Roughness.IsFrozen,
                        "Material channel brush cannot cross thread boundary");
                if (Path.GetFileName(fixture).StartsWith("maxPbrMaterial_metalRough", StringComparison.OrdinalIgnoreCase))
                {
                    Check(result.MetalnessChannels > 0 && result.RoughnessChannels > 0, "3ds Max PBR channels were not detected");
                    var metal = result.Appearances[0].Metalness as SolidColorBrush;
                    var rough = result.Appearances[0].Roughness as SolidColorBrush;
                    Check(metal != null && Math.Abs(metal.Color.R - 64) <= 1, "Metalness scalar was not read as 0.25");
                    Check(rough != null && Math.Abs(rough.Color.R - 128) <= 1, "Roughness scalar was not read as 0.5");
                    Console.WriteLine("PASS 3ds Max FBX metalness 0.25 and roughness 0.5 channels");
                }
                var b = result.Model.Bounds;
                Check(Math.Abs(Math.Max(b.SizeX, Math.Max(b.SizeY, b.SizeZ)) - 2) < 0.001, "Normalization failed");
                Check(Math.Abs(b.X + b.SizeX / 2) < 0.001 && Math.Abs(b.Y + b.SizeY / 2) < 0.001 && Math.Abs(b.Z + b.SizeZ / 2) < 0.001, "Centering failed");
                Console.WriteLine("PASS {0}: {1} meshes, {2} triangles, {3} texture fallbacks", Path.GetFileName(fixture), result.Meshes, result.Triangles, result.MissingTextures);
                if (first == null) first = result;
            }
            var view = new ModelView(); view.ShowModel(first);
            for (int material = 0; material < 5; material++) view.SetMaterialMode(material);
            for (int light = 0; light < 6; light++) view.SetLightPreset(light);
            view.SetMaterialMode(3);
            view.SetLightPreset(1);
            view.Measure(new Size(960, 700)); view.Arrange(new Rect(0, 0, 960, 700)); view.UpdateLayout();
            view.SetWireframe(true);
            Check(view.WireEdgeCount > 0, "Wireframe edges were not generated");
            var bitmap = new RenderTargetBitmap(960, 700, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(view);
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using (var stream = File.Create("preview-test.png")) encoder.Save(stream);
            view.Release();
            Console.WriteLine("PASS 5 material modes, 6 light presets, wireframe overlay, WPF render and cleanup");
            return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
    }
}
