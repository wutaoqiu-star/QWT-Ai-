param(
    [Parameter(Mandatory = $true)][string]$QuickLookDirectory,
    [Parameter(Mandatory = $true)][string[]]$FbxFiles
)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$testSource = Join-Path $PSScriptRoot 'SmokeTests.cs'
& "$root/build.ps1" -QuickLookDirectory $QuickLookDirectory
$testOut = Join-Path $root 'test-build'
New-Item -ItemType Directory -Force $testOut | Out-Null
Copy-Item "$root/build/*" $testOut -Recurse -Force
Copy-Item (Join-Path $QuickLookDirectory 'QuickLook.Common.dll') $testOut
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$framework = Split-Path $compiler
$argsList = @('/nologo', '/target:exe', '/platform:anycpu', "/out:$testOut/SmokeTests.exe",
    "/reference:$testOut/QuickLook.Common.dll", "/reference:$testOut/AssimpNet.dll",
    "/reference:$framework/WPF/PresentationCore.dll", "/reference:$framework/WPF/PresentationFramework.dll",
    "/reference:$framework/WPF/WindowsBase.dll", "/reference:$framework/System.Xaml.dll")
$sources = Get-ChildItem $root -Filter '*.cs' | ForEach-Object { $_.FullName }
& $compiler @argsList @sources $testSource
if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed.' }
$fixtures = @($FbxFiles | ForEach-Object { (Resolve-Path -LiteralPath $_).Path })
Push-Location $testOut
try {
    & './SmokeTests.exe' @fixtures
    if ($LASTEXITCODE -ne 0) { throw 'Smoke tests failed.' }
} finally { Pop-Location }
