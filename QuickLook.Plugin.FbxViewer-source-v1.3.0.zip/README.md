# QuickLook FBX 预览插件

[![Build](https://github.com/wutaoqiu-star/QWT-Ai-/actions/workflows/build.yml/badge.svg)](https://github.com/wutaoqiu-star/QWT-Ai-/actions/workflows/build.yml)
[![Release](https://img.shields.io/github/v/release/wutaoqiu-star/QWT-Ai-)](https://github.com/wutaoqiu-star/QWT-Ai-/releases/latest)

在 Windows 文件资源管理器选中 `.fbx`，按空格显示静态模型。

当前版本：**1.3.0**。重做专业深色界面，加入 Substance 3D Painter 风格的视口导航，并可检查材质、白模、漫反射、金属度、粗糙度和线框。

![QuickLook FBX 预览界面](docs/preview.png)

可从 [GitHub Releases](https://github.com/wutaoqiu-star/QWT-Ai-/releases/latest) 下载 `QuickLook.Plugin.FbxViewer-v1.3.0.qlplugin`；仓库中的 CI 也会在 Windows 上构建可安装包。

## 安装

1. 安装并运行 Windows 版 QuickLook。本版本基于官方 **QuickLook 4.5.0** 的 `QuickLook.Common.dll` 编译。
2. 在文件资源管理器选中 `QuickLook.Plugin.FbxViewer.qlplugin`，按 **空格**。
3. 在 QuickLook 显示的插件安装界面点击安装，完成后退出并重新启动 QuickLook。
4. 选中 FBX 文件，按空格预览。

不需要安装 Blender 或 Autodesk FBX SDK。依赖已包含在安装包内，预览时不访问网络。
未在本次开发过程中修改你现有的 QuickLook 安装。

## 功能与操作

- FBX 静态三角网格；通过 Assimp 读取二进制和 ASCII FBX（具体兼容性受解析器支持范围限制）。
- 支持中文文件名及中文目录；文件由 .NET 以 Unicode 路径打开，再通过数据流交给 Assimp。
- 应用场景节点变换，再将模型居中并统一预览尺寸。
- 漫反射颜色、UV0、WPF 可解码的外部图片纹理及压缩嵌入图片纹理。
- `Alt + 左键拖动`：环绕相机；`Alt + Shift + 左键拖动`：释放时吸附到 90° 视角。
- `Alt + 中键拖动` 或 `Ctrl + Alt + 左键拖动`：平移相机。
- `Alt + 右键拖动` 或滚轮：推拉缩放。
- `Shift + 右键拖动`：水平旋转环境灯；灯光菜单仍可直接选择预设方向。
- `F`：将整个模型重新居中并恢复合适视距；顶部按钮也可重置视角。
- 顶部显示模式为互斥切换：材质、白模、漫反射、金属度、粗糙度。漫反射及 PBR 通道使用无光照显示，便于查看贴图本身。
- FBX 含 Base Color、Metalness、Roughness 贴图或标量时会读取对应数据；缺失金属度时显示默认值 0，缺失粗糙度时显示默认值 0.5，并在底部状态栏提示。
- 灯光菜单可切换左前上、右前上、左后上、右后上、正面和顶部照明；拖动灯光后显示为“自定义”。
- 线框复选框可在材质表面叠加拓扑线，`Alt + W` 快速切换。Substance Painter 本身把线框作为视口设置且没有默认线框快捷键，因此这里使用不占用 Painter `W` 移动工具的组合键。
- 显示网格和三角面数量；纹理缺失时使用材质颜色并显示提示。
- 后台导入，切换文件或关闭预览后丢弃旧任务结果，释放视图引用。

外部纹理应放在 FBX 同目录或子目录，并保留相对路径。导出文件内记录的外部绝对路径会尝试匹配 FBX 同目录的同名图片。

## 范围与限制

- 这是静态模型预览器，不播放骨骼动画、变形动画，不提供编辑或导出。
- “材质”模式使用 WPF 漫反射渲染，不实现完整 PBR 光照、法线贴图、透明排序或专业 DCC 材质系统。金属度和粗糙度模式用于查看原始灰度通道，不参与 WPF 材质模式的光照计算。
- 未压缩嵌入纹理、WPF 不支持的图片编码会回退到材质底色。
- 文件上限 256 MB；导入后的模型上限为 300 万顶点和 200 万三角面。外部纹理文件上限 64 MB，解码宽度限制为 2048 像素。
- 原生 Assimp 导入不能在中途强行取消；关闭窗口后结果不会再显示，后台导入会完成后释放。复杂文件仍可能消耗较多时间和内存，网格限制在导入完成后检查。
- 为保持交互流畅，超过 120,000 个三角面的模型会停用线框叠加；模型和材质预览仍可使用。
- 包含 x64、x86 原生依赖；本次实际测试为 Windows x64。ARM64 原生 QuickLook 不适用。其他 QuickLook 版本须实际验证接口兼容性。
- FBX 有多种版本和导出器差异，不承诺支持所有 FBX 文件。

## 从源码构建

源码包已包含 AssimpNet 及对应原生库。构建需 Windows x64 上的 .NET Framework 4.6.2 或更新版本，以及一个 QuickLook 程序目录。

无需下载 .NET SDK，可以使用 Windows 自带的 .NET Framework C# 编译器：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -QuickLookDirectory "C:\Apps\QuickLook"
```

这里的目录必须包含 `QuickLook.Common.dll`。脚本只在项目目录中生成 `build` 和 `.qlplugin`，不会修改 QuickLook。`ExecutionPolicy Bypass` 只针对本次 PowerShell 进程。

也可用 Visual Studio / .NET SDK 打开 `.csproj`：

```powershell
dotnet build .\QuickLook.Plugin.FbxViewer.csproj -c Release -p:QuickLookDirectory="C:\Apps\QuickLook"
```

SDK 构建需要 .NET Framework 4.6.2 targeting pack。安装包由 `build.ps1` 生成，包内不要加入 `QuickLook.Common.dll`，它由宿主提供。

## 测试

```powershell
.\tests\test.ps1 -QuickLookDirectory "C:\Apps\QuickLook" -FbxFiles @("C:\Models\box.fbx")
```

测试覆盖文件识别、损坏文件拒绝、预先取消、真实 FBX 导入、归一化与居中、跨线程可用的冻结模型、WPF 离屏渲染及视图释放。输出在 `test-build`。测试不会安装插件。

本次测试结果详见同目录 `VALIDATION.md`。离屏渲染验证不等同于在 QuickLook 窗口中实际操作鼠标；安装后的空格唤起和交互仍需在你的 QuickLook 环境确认。

## 实现与来源

- `Plugin.cs`：实现 `IViewer` 生命周期和异步加载。
- `ModelLoader.cs`：Assimp 导入、材质与纹理、几何转换。
- `ModelView.cs`：WPF 视口、灯光、轨道相机和鼠标交互。
- `QuickLook.Plugin.Metadata.config`：官方安装器读取的插件元数据。
- `build.ps1`：编译并将 ZIP 内容打包为 `.qlplugin`。

开发依据：

- https://github.com/QL-Win/QuickLook/wiki/Develop%2C-build-and-integrate
- https://github.com/QL-Win/QuickLook.Plugin.HelloWorld
- https://github.com/QL-Win/QuickLook/tree/master/QuickLook.Common/Plugin
- https://github.com/QL-Win/QuickLook/releases/tag/4.5.0
- https://www.nuget.org/packages/AssimpNet/5.0.0-beta1
- https://github.com/assimp/assimp/tree/master/test/models/FBX
- https://experienceleague.adobe.com/en/docs/substance-3d-painter/using/interface/viewport/viewport
- https://experienceleague.adobe.com/en/docs/substance-3d-painter/using/interface/settings/shortcuts
- https://experienceleague.adobe.com/en/docs/substance-3d-painter/using/interface/display-settings/viewport-settings

依赖固定为 **AssimpNet 5.0.0-beta1**（含匹配的原生 Assimp）。该包名含 beta；使用它是因为 4.1.0 在本次有效 FBX 样例上返回空场景，而 5.0.0-beta1 可以正确读取。升级时必须同时替换托管与原生依赖并重跑测试。

本插件源码采用 GPL-3.0-or-later，详见 `LICENSE.txt`。AssimpNet 与 Assimp 许可见 `THIRD-PARTY-NOTICES.txt`。
