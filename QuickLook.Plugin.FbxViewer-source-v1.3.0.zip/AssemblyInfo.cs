using System.Reflection;
[assembly: AssemblyTitle("QuickLook.Plugin.FbxViewer")]
[assembly: AssemblyVersion("1.3.0.0")]
[assembly: AssemblyFileVersion("1.3.0.0")]
