// SPDX-License-Identifier: GPL-3.0-or-later
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Assimp;
using Vector3D = System.Windows.Media.Media3D.Vector3D;

namespace QuickLook.Plugin.FbxViewer
{
    internal sealed class ModelResult
    {
        public Model3DGroup Model;
        public int Meshes, Triangles, MissingTextures;
        public int MetalnessChannels, RoughnessChannels;
        public readonly List<MeshAppearance> Appearances = new List<MeshAppearance>();
        public Point3DCollection WirePoints;
    }
    internal sealed class MeshAppearance
    {
        public System.Windows.Media.Media3D.Material Surface;
        public Brush Diffuse;
        public Brush Metalness;
        public Brush Roughness;
        public bool HasMetalness;
        public bool HasRoughness;
    }
    internal static class ModelLoader
    {
        private static readonly object ImportLock = new object();
        internal static ModelResult Load(string path, CancellationToken token)
        {
            // Assimp's native library is process-wide. Serialize loading/importing.
            lock (ImportLock)
            {
                token.ThrowIfCancellationRequested();
                if (new FileInfo(path).Length > 256L * 1024 * 1024)
                    throw new InvalidDataException("文件超过 256 MB 预览上限。");
                string folder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                Assimp.Unmanaged.AssimpLibrary.Instance.LoadLibrary(Path.Combine(folder,
                    "native", IntPtr.Size == 8 ? "x64" : "x86", "assimp.dll"));
                using (var importer = new AssimpContext())
                {
                    // Assimp's native path API is not reliable with non-ASCII Windows paths.
                    // Let .NET open the Unicode path and pass the bytes to Assimp instead.
                    Scene scene;
                    using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read,
                        FileShare.ReadWrite | FileShare.Delete))
                    {
                        scene = importer.ImportFileFromStream(stream, PostProcessSteps.Triangulate |
                            PostProcessSteps.JoinIdenticalVertices | PostProcessSteps.GenerateSmoothNormals |
                            PostProcessSteps.PreTransformVertices | PostProcessSteps.SortByPrimitiveType, "fbx");
                    }
                    token.ThrowIfCancellationRequested();
                    if (scene == null || !scene.HasMeshes)
                        throw new InvalidDataException("文件不包含可显示的网格。");
                    var result = new ModelResult { Model = new Model3DGroup() };
                    long vertices = 0;
                    foreach (var mesh in scene.Meshes)
                    {
                        token.ThrowIfCancellationRequested();
                        vertices += mesh.VertexCount;
                        if (vertices > 3000000 || result.Triangles + (long)mesh.FaceCount > 2000000)
                            throw new InvalidDataException("模型过于复杂（上限 300 万顶点 / 200 万三角面）。");
                        var geometry = new MeshGeometry3D();
                        foreach (var p in mesh.Vertices)
                        {
                            if (Single.IsNaN(p.X) || Single.IsInfinity(p.X) ||
                                Single.IsNaN(p.Y) || Single.IsInfinity(p.Y) ||
                                Single.IsNaN(p.Z) || Single.IsInfinity(p.Z))
                                throw new InvalidDataException("模型包含无效坐标。");
                            geometry.Positions.Add(new Point3D(p.X, p.Y, p.Z));
                        }
                        if (mesh.HasNormals)
                            foreach (var n in mesh.Normals) geometry.Normals.Add(new Vector3D(n.X, n.Y, n.Z));
                        if (mesh.HasTextureCoords(0))
                            foreach (var uv in mesh.TextureCoordinateChannels[0])
                                geometry.TextureCoordinates.Add(new Point(uv.X, 1 - uv.Y));
                        foreach (var face in mesh.Faces)
                        {
                            if (face.IndexCount != 3) continue;
                            foreach (int index in face.Indices)
                            {
                                if (index < 0 || index >= mesh.VertexCount) throw new InvalidDataException("无效网格索引。");
                                geometry.TriangleIndices.Add(index);
                            }
                            result.Triangles++;
                        }
                        if (geometry.TriangleIndices.Count == 0) continue;
                        var appearance = CreateAppearance(scene, mesh.MaterialIndex, path, result);
                        var model = new GeometryModel3D(geometry, appearance.Surface) { BackMaterial = appearance.Surface };
                        result.Model.Children.Add(model);
                        result.Appearances.Add(appearance);
                        result.Meshes++;
                    }
                    if (result.Meshes == 0) throw new InvalidDataException("文件没有三角面网格。");
                    // Normalize units and center without changing the FBX's proportions.
                    var bounds = result.Model.Bounds;
                    double extent = Math.Max(bounds.SizeX, Math.Max(bounds.SizeY, bounds.SizeZ));
                    if (extent <= 1e-12 || Double.IsInfinity(extent)) throw new InvalidDataException("模型尺寸无效。");
                    var transform = new Transform3DGroup();
                    transform.Children.Add(new TranslateTransform3D(-bounds.X - bounds.SizeX / 2,
                        -bounds.Y - bounds.SizeY / 2, -bounds.Z - bounds.SizeZ / 2));
                    transform.Children.Add(new ScaleTransform3D(2 / extent, 2 / extent, 2 / extent));
                    result.Model.Transform = transform;
                    if (result.Triangles <= 120000)
                        result.WirePoints = BuildWirePoints(result.Model, transform.Value, token);
                    result.Model.Freeze();
                    return result;
                }
            }
        }
        private static Point3DCollection BuildWirePoints(Model3DGroup model, Matrix3D transform, CancellationToken token)
        {
            var points = new Point3DCollection();
            foreach (Model3D child in model.Children)
            {
                token.ThrowIfCancellationRequested();
                var geometryModel = child as GeometryModel3D;
                var geometry = geometryModel == null ? null : geometryModel.Geometry as MeshGeometry3D;
                if (geometry == null) continue;
                var edges = new HashSet<long>();
                for (int i = 0; i + 2 < geometry.TriangleIndices.Count; i += 3)
                {
                    AddEdge(edges, geometry.TriangleIndices[i], geometry.TriangleIndices[i + 1]);
                    AddEdge(edges, geometry.TriangleIndices[i + 1], geometry.TriangleIndices[i + 2]);
                    AddEdge(edges, geometry.TriangleIndices[i + 2], geometry.TriangleIndices[i]);
                }
                foreach (long edge in edges)
                {
                    int a = (int)(edge >> 32);
                    int b = (int)(edge & UInt32.MaxValue);
                    points.Add(transform.Transform(geometry.Positions[a]));
                    points.Add(transform.Transform(geometry.Positions[b]));
                }
            }
            points.Freeze();
            return points;
        }
        private static void AddEdge(HashSet<long> edges, int a, int b)
        {
            uint low = (uint)Math.Min(a, b), high = (uint)Math.Max(a, b);
            edges.Add(((long)low << 32) | high);
        }
        private static MeshAppearance CreateAppearance(Scene scene, int index, string path, ModelResult result)
        {
            Brush diffuse = CreateGrayBrush(0.72f);
            Brush metalness = CreateGrayBrush(0f);
            Brush roughness = CreateGrayBrush(0.5f);
            bool hasMetalness = false, hasRoughness = false;
            if (index >= 0 && index < scene.MaterialCount)
            {
                var material = scene.Materials[index];
                if (material.HasColorDiffuse)
                {
                    var c = material.ColorDiffuse;
                    diffuse = Freeze(new SolidColorBrush(Color.FromScRgb(1, c.R, c.G, c.B)));
                }
                TextureSlot diffuseSlot = default(TextureSlot);
                bool hasDiffuseTexture = material.PBR.HasTextureBaseColor || material.HasTextureDiffuse;
                if (hasDiffuseTexture)
                {
                    diffuseSlot = material.PBR.HasTextureBaseColor ? material.PBR.TextureBaseColor : material.TextureDiffuse;
                    diffuse = LoadTextureOrFallback(scene, diffuseSlot.FilePath, path, diffuse, result);
                }
                else
                {
                    string rawBaseColor;
                    if (TryGetRawTexture(material, "base_color_map|file", out rawBaseColor))
                        diffuse = LoadTextureOrFallback(scene, rawBaseColor, path, diffuse, result);
                }
                float value;
                if (TryGetFloat(material, "$mat.metallicFactor", out value) ||
                    TryGetFloat(material, "$mat.metalness", out value) ||
                    TryGetFloat(material, "$raw.3dsMax|main|metalness", out value))
                { metalness = CreateGrayBrush(value); hasMetalness = true; }
                if (material.PBR.HasTextureMetalness)
                {
                    metalness = LoadTextureOrFallback(scene, material.PBR.TextureMetalness.FilePath, path, metalness, result);
                    hasMetalness = true;
                }
                else
                {
                    string rawMetalness;
                    if (TryGetRawTexture(material, "metalness_map|file", out rawMetalness))
                    { metalness = LoadTextureOrFallback(scene, rawMetalness, path, metalness, result); hasMetalness = true; }
                }

                if (TryGetFloat(material, "$mat.roughnessFactor", out value) ||
                    TryGetFloat(material, "$mat.roughness", out value) ||
                    TryGetFloat(material, "$raw.3dsMax|main|roughness", out value))
                { roughness = CreateGrayBrush(value); hasRoughness = true; }
                if (material.PBR.HasTextureRoughness)
                {
                    roughness = LoadTextureOrFallback(scene, material.PBR.TextureRoughness.FilePath, path, roughness, result);
                    hasRoughness = true;
                }
                else
                {
                    string rawRoughness;
                    if (TryGetRawTexture(material, "roughness_map|file", out rawRoughness))
                    { roughness = LoadTextureOrFallback(scene, rawRoughness, path, roughness, result); hasRoughness = true; }
                    else if (!hasRoughness && material.HasShininess)
                    {
                        roughness = CreateGrayBrush((float)Math.Sqrt(2.0 / Math.Max(2.0, material.Shininess + 2.0)));
                        hasRoughness = true;
                    }
                }
            }
            if (hasMetalness) result.MetalnessChannels++;
            if (hasRoughness) result.RoughnessChannels++;
            var surface = new DiffuseMaterial(diffuse);
            surface.Freeze();
            return new MeshAppearance
            {
                Surface = surface, Diffuse = diffuse, Metalness = metalness, Roughness = roughness,
                HasMetalness = hasMetalness, HasRoughness = hasRoughness
            };
        }
        private static bool TryGetFloat(Assimp.Material material, string name, out float value)
        {
            foreach (var property in material.GetAllProperties())
            {
                if (!String.Equals(property.Name, name, StringComparison.OrdinalIgnoreCase)) continue;
                try { value = property.GetFloatValue(); return true; }
                catch (Exception) { break; }
            }
            value = 0;
            return false;
        }
        private static bool TryGetRawTexture(Assimp.Material material, string nameFragment, out string path)
        {
            foreach (var property in material.GetAllProperties())
            {
                if (property.Name.IndexOf(nameFragment, StringComparison.OrdinalIgnoreCase) < 0) continue;
                try
                {
                    path = property.GetStringValue();
                    return !String.IsNullOrWhiteSpace(path);
                }
                catch (Exception) { break; }
            }
            path = null;
            return false;
        }
        private static Brush LoadTextureOrFallback(Scene scene, string name, string path, Brush fallback, ModelResult result)
        {
            try { return Freeze(new ImageBrush(LoadBitmap(scene, name, path))); }
            catch (Exception ex)
            {
                if (!(ex is IOException || ex is ArgumentException || ex is NotSupportedException || ex is System.Runtime.InteropServices.COMException)) throw;
                result.MissingTextures++;
                return fallback;
            }
        }
        private static BitmapSource LoadBitmap(Scene scene, string name, string path)
        {
            if (name.StartsWith("*", StringComparison.Ordinal))
            {
                int textureIndex;
                if (!Int32.TryParse(name.Substring(1), out textureIndex) || textureIndex < 0 || textureIndex >= scene.TextureCount)
                    throw new InvalidDataException("嵌入纹理索引无效。");
                var embedded = scene.Textures[textureIndex];
                if (!embedded.IsCompressed) throw new NotSupportedException("未压缩嵌入纹理暂不支持。");
                using (var stream = new MemoryStream(embedded.CompressedData)) return Decode(stream);
            }
            // Restrict texture access to this model's directory tree; no network or absolute external paths.
            string root = Path.GetFullPath(Path.GetDirectoryName(path)) + Path.DirectorySeparatorChar;
            name = name.Replace('/', Path.DirectorySeparatorChar);
            string candidate = Path.GetFullPath(Path.Combine(root, name));
            if (!candidate.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(candidate))
                candidate = Path.Combine(root, Path.GetFileName(name));
            if (!File.Exists(candidate) || new FileInfo(candidate).Length > 64L * 1024 * 1024)
                throw new FileNotFoundException("找不到纹理或纹理过大。");
            using (var stream = File.OpenRead(candidate)) return Decode(stream);
        }
        private static Brush CreateGrayBrush(float value)
        {
            value = Math.Max(0, Math.Min(1, value));
            byte channel = (byte)Math.Round(value * 255);
            return Freeze(new SolidColorBrush(Color.FromRgb(channel, channel, channel)));
        }
        private static T Freeze<T>(T value) where T : Freezable
        {
            if (value.CanFreeze) value.Freeze();
            return value;
        }
        private static BitmapSource Decode(Stream stream)
        {
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.DecodePixelWidth = 2048;
            bitmap.StreamSource = stream;
            bitmap.EndInit();
            bitmap.Freeze();
            return bitmap;
        }
    }
}
