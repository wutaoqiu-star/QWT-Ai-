param(
    [Parameter(Mandatory = $true)][string]$QuickLookDirectory
)
$ErrorActionPreference = 'Stop'
$common = Join-Path $QuickLookDirectory 'QuickLook.Common.dll'
if (!(Test-Path -LiteralPath $common)) { throw "QuickLook.Common.dll not found: $common" }
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$framework = Split-Path $compiler
$out = Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$argsList = @('/nologo', '/target:library', '/optimize+', '/platform:anycpu',
    "/out:$out/QuickLook.Plugin.FbxViewer.dll", "/reference:$common",
    "/reference:$PSScriptRoot/lib/AssimpNet.dll", "/reference:$framework/WPF/PresentationCore.dll",
    "/reference:$framework/WPF/PresentationFramework.dll", "/reference:$framework/WPF/WindowsBase.dll",
    "/reference:$framework/System.Xaml.dll")
$sources = Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' | ForEach-Object { $_.FullName }
& $compiler @argsList @sources
if ($LASTEXITCODE -ne 0) { throw 'C# compilation failed.' }
Copy-Item -LiteralPath "$PSScriptRoot/lib/AssimpNet.dll" -Destination $out
Copy-Item -LiteralPath "$PSScriptRoot/native" -Destination $out -Recurse -Force
Copy-Item -LiteralPath "$PSScriptRoot/QuickLook.Plugin.Metadata.config" -Destination $out
Copy-Item -LiteralPath "$PSScriptRoot/THIRD-PARTY-NOTICES.txt" -Destination $out
Copy-Item -LiteralPath "$PSScriptRoot/LICENSE.txt" -Destination $out
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = Join-Path $PSScriptRoot 'QuickLook.Plugin.FbxViewer.qlplugin'
if (Test-Path -LiteralPath $archive) { Remove-Item -LiteralPath $archive }
[IO.Compression.ZipFile]::CreateFromDirectory($out, $archive)
Write-Host "Built $archive"
