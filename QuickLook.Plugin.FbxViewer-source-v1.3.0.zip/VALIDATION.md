# 验证记录

日期：2026-09-14。环境：Windows x64、系统 .NET Framework C# 编译器。

## 构建

- 引用 QuickLook 官方 4.5.0 ZIP 发布包内的真实 `QuickLook.Common.dll`。
- `build.ps1` 编译成功，没有编译错误或警告。
- AssimpNet 5.0.0-beta1 的托管 DLL 与 x64/x86 原生 DLL 一起打包。
- 安装包根目录含 `QuickLook.Plugin.Metadata.config` 和 `QuickLook.Plugin.FbxViewer.dll`；没有打包宿主的 `QuickLook.Common.dll`。

## 实际运行测试

使用 Assimp 官方仓库 `test/models/FBX` 中的样例，运行源码中的 `tests/test.ps1`：

| 样例 | 网格 | 三角面 | 结果 |
|---|---:|---:|---|
| box.fbx | 1 | 12 | 导入、居中、尺寸归一化通过 |
| cubes_with_mirroring_and_pivot.fbx | 2 | 420 | 导入、居中、尺寸归一化通过 |
| animation_with_skeleton.fbx | 1 | 2112 | 静态网格导入通过；未播放动画 |
| box_orphant_embedded_texture.fbx | 1 | 12 | 网格导入通过；1 个纹理回退到底色 |
| 用户的 `房间.fbx` | 39 | 8746 | 中文路径、5 种显示模式、线框生成及渲染通过 |
| maxPbrMaterial_metalRough.fbx | 1 | 12 | 3ds Max FBX 金属度 0.25、粗糙度 0.5 读取通过；缺失外部贴图回退到标量 |

其他通过项：不存在文件及目录拒绝、`.FBX` 大写扩展名、损坏 FBX 拒绝、预先取消任务、冻结后的 WPF 模型、960×700 离屏渲染、视图释放。

版本 1.0.1 增加中文路径回归测试：将有效样例复制为 `中文目录\房间.fbx`，再通过流式导入，网格和三角面读取成功。

版本 1.1.0 增加 5 种材质模式和 6 种灯光方向。测试逐项切换所有模式，再以陶土材质、右前上灯光完成 960×700 WPF 离屏渲染。

版本 1.2.0 按 Adobe Substance 3D Painter 官方文档实现相机操作：Alt+左键环绕、Alt+Shift+左键 90° 吸附、Alt+中键及 Ctrl+Alt+左键平移、Alt+右键与滚轮缩放、Shift+右键旋转环境灯、F 聚焦整个模型。线框可通过复选框或插件自定义的 Alt+W 切换。

线框测试从 `房间.fbx` 的三角网格建立去重边集合，生成面向相机的屏幕等宽线条并完成离屏渲染。超过 120,000 个三角面时主动停用线框，防止高密度模型拖慢交互。

版本 1.3.0 重做深色分组工具栏和底部状态栏，将材质、白模、漫反射、金属度、粗糙度改为互斥显示模式，线框保留为独立叠加层。加载器增加 Base Color、Metalness、Roughness 纹理和标量读取；缺少通道时使用明确的默认值并显示黄色提示。

Alt+W 修复测试同时覆盖普通 `Key.W` 和 WPF 在按住 Alt 时实际产生的 `Key.System + SystemKey.W`，并确认未按 Alt 的 W 不会误触发。

已查看离屏渲染截图，深色分组工具栏、互斥显示模式、灯光菜单、线框状态、模型和底部通道提示正常显示。

## 未验证的项目

- 未将插件安装进用户正在使用的 QuickLook，也未实际测试文件资源管理器空格唤起、鼠标拖动及安装器按钮流程。
- 未在 x86 QuickLook、ARM64、其他 QuickLook 版本验证。
- 未全面验证各类 FBX 导出器、外部及嵌入纹理组合；缺失纹理回退样例已运行。
- 超大模型内存峰值、原生导入期间取消，以及高频打开/关闭未做压力测试。

早期尝试的 AssimpNet 4.1.0 对 box.fbx 返回空场景，因此最终包改用 5.0.0-beta1，并重新运行上述测试。
