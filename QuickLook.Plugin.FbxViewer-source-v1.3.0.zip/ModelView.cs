// SPDX-License-Identifier: GPL-3.0-or-later
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace QuickLook.Plugin.FbxViewer
{
    internal sealed class ModelView : Grid
    {
        private static readonly Brush PanelBrush = FrozenBrush(Color.FromRgb(35, 39, 49));
        private static readonly Brush PanelRaisedBrush = FrozenBrush(Color.FromRgb(47, 53, 66));
        private static readonly Brush HoverBrush = FrozenBrush(Color.FromRgb(58, 66, 82));
        private static readonly Brush AccentBrush = FrozenBrush(Color.FromRgb(68, 142, 247));
        private static readonly Brush TextBrush = FrozenBrush(Color.FromRgb(231, 235, 242));
        private static readonly Brush MutedBrush = FrozenBrush(Color.FromRgb(155, 164, 179));
        private static readonly Brush BorderBrush = FrozenBrush(Color.FromRgb(62, 69, 84));
        private static readonly Brush WarningBrush = FrozenBrush(Color.FromRgb(245, 190, 92));

        private readonly Viewport3D viewport = new Viewport3D();
        private readonly PerspectiveCamera camera = new PerspectiveCamera { FieldOfView = 45, NearPlaneDistance = 0.01, FarPlaneDistance = 500 };
        private readonly TextBlock status = new TextBlock { Foreground = TextBrush, VerticalAlignment = VerticalAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis };
        private readonly ModelVisual3D visual = new ModelVisual3D();
        private readonly DirectionalLight keyLight = new DirectionalLight(Colors.White, new Vector3D(-1, -2, -3));
        private readonly DirectionalLight fillLight = new DirectionalLight(Color.FromRgb(90, 100, 120), new Vector3D(1, 0, 1));
        private readonly Button lightButton;
        private readonly ContextMenu lightMenu = new ContextMenu { Background = PanelBrush, BorderBrush = BorderBrush, BorderThickness = new Thickness(1), Padding = new Thickness(3) };
        private readonly ToggleButton wireToggle;
        private readonly List<ToggleButton> modeButtons = new List<ToggleButton>();
        private readonly WireframeVisual wireframe = new WireframeVisual();
        private readonly List<MaterialSlot> materialSlots = new List<MaterialSlot>();
        private readonly Border surface;
        private static readonly string[] ModeNames = { "材质", "白模", "漫反射", "金属度", "粗糙度" };
        private static readonly Vector3D[] LightDirections =
        {
            new Vector3D(1, -1.5, -2), new Vector3D(-1, -1.5, -2),
            new Vector3D(1, -1.5, 2), new Vector3D(-1, -1.5, 2),
            new Vector3D(0, 0, -1), new Vector3D(0, -1, 0)
        };

        private Point previous;
        private double yaw = 0.7, pitch = 0.35, distance = 4.5;
        private Point3D center = new Point3D();
        private DragMode dragMode;
        private bool snapOrbit;
        private int selectedMode;
        private string baseStatus = "正在读取 FBX…";
        private int meshCount, metalnessChannels, roughnessChannels;
        private int selectedLight;

        internal ModelView()
        {
            var background = new RadialGradientBrush
            {
                Center = new Point(0.5, 0.38), GradientOrigin = new Point(0.5, 0.38),
                RadiusX = 0.85, RadiusY = 0.85
            };
            background.GradientStops.Add(new GradientStop(Color.FromRgb(39, 44, 54), 0));
            background.GradientStops.Add(new GradientStop(Color.FromRgb(22, 25, 32), 1));
            Background = background;
            ClipToBounds = true;
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(56) });
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(36) });

            var topBar = new Border
            {
                Background = PanelBrush, BorderBrush = BorderBrush,
                BorderThickness = new Thickness(0, 0, 0, 1), Padding = new Thickness(12, 9, 12, 8)
            };
            var toolbar = new Grid();
            toolbar.ColumnDefinitions.Add(new ColumnDefinition());
            toolbar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            topBar.Child = toolbar;

            var left = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            var badge = new Border { Background = AccentBrush, CornerRadius = new CornerRadius(5), Padding = new Thickness(8, 4, 8, 4), Margin = new Thickness(0, 0, 10, 0) };
            badge.Child = new TextBlock { Text = "FBX", Foreground = Brushes.White, FontWeight = FontWeights.SemiBold, FontSize = 12 };
            left.Children.Add(badge);
            left.Children.Add(new TextBlock { Text = "预览", Foreground = TextBrush, FontSize = 15, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 14, 0) });

            var modeGroup = new Border { Background = FrozenBrush(Color.FromRgb(28, 32, 40)), CornerRadius = new CornerRadius(6), Padding = new Thickness(3) };
            var modePanel = new StackPanel { Orientation = Orientation.Horizontal };
            modeGroup.Child = modePanel;
            for (int i = 0; i < ModeNames.Length; i++)
            {
                int mode = i;
                var button = CreateToggleButton(ModeNames[i], 66);
                button.ToolTip = GetModeToolTip(i);
                button.Click += delegate { SelectMode(mode); };
                modeButtons.Add(button);
                modePanel.Children.Add(button);
            }
            left.Children.Add(modeGroup);
            toolbar.Children.Add(left);

            var right = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(right, 1);
            wireToggle = CreateToggleButton("○  线框  Alt+W", 108);
            wireToggle.Margin = new Thickness(10, 0, 12, 0);
            wireToggle.ToolTip = "在当前显示模式上叠加网格线框（Alt+W）";
            wireToggle.Checked += delegate
            { wireToggle.Content = "●  线框  Alt+W"; RefreshToggle(wireToggle); wireframe.IsEnabled = true; UpdateWireframe(); UpdateStatus(); };
            wireToggle.Unchecked += delegate
            { wireToggle.Content = "○  线框  Alt+W"; RefreshToggle(wireToggle); wireframe.IsEnabled = false; UpdateStatus(); };
            right.Children.Add(wireToggle);
            string[] lightNames = { "左前上", "右前上", "左后上", "右后上", "正面", "顶部" };
            lightButton = CreateActionButton("灯光 · 左前上  ▾", 140);
            lightButton.ToolTip = "选择灯光方向；Shift+右键拖动可连续旋转";
            for (int i = 0; i < lightNames.Length; i++)
            {
                int lightIndex = i;
                var item = new MenuItem
                {
                    Header = lightNames[i], Foreground = TextBrush, Background = PanelBrush,
                    Padding = new Thickness(14, 7, 22, 7), FontSize = 12
                };
                item.Click += delegate { SetLightPreset(lightIndex); surface.Focus(); };
                lightMenu.Items.Add(item);
            }
            lightButton.Click += delegate
            {
                lightMenu.PlacementTarget = lightButton;
                lightMenu.Placement = PlacementMode.Bottom;
                lightMenu.IsOpen = true;
            };
            right.Children.Add(lightButton);
            var focusButton = CreateActionButton("聚焦  F", 76);
            focusButton.Margin = new Thickness(10, 0, 0, 0);
            focusButton.ToolTip = "将整个模型重新居中（F）";
            focusButton.Click += delegate { Reset(); surface.Focus(); };
            right.Children.Add(focusButton);
            toolbar.Children.Add(right);
            Children.Add(topBar);

            surface = new Border { Background = Brushes.Transparent, Child = viewport, ClipToBounds = true, Focusable = true };
            SetRow(surface, 1);
            Children.Add(surface);

            var statusBar = new Border { Background = PanelBrush, BorderBrush = BorderBrush, BorderThickness = new Thickness(0, 1, 0, 0), Padding = new Thickness(12, 0, 12, 0) };
            var statusGrid = new Grid();
            statusGrid.ColumnDefinitions.Add(new ColumnDefinition());
            statusGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            statusGrid.Children.Add(status);
            var shortcutHint = new TextBlock
            {
                Text = "Alt+拖动导航   Shift+右键灯光   F聚焦",
                Foreground = MutedBrush, FontSize = 11, VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(shortcutHint, 1);
            statusGrid.Children.Add(shortcutHint);
            statusBar.Child = statusGrid;
            SetRow(statusBar, 2);
            Children.Add(statusBar);

            viewport.Camera = camera;
            var lights = new Model3DGroup();
            lights.Children.Add(new AmbientLight(Color.FromRgb(100, 104, 114)));
            lights.Children.Add(keyLight);
            lights.Children.Add(fillLight);
            viewport.Children.Add(new ModelVisual3D { Content = lights });
            viewport.Children.Add(visual);
            viewport.Children.Add(wireframe);
            SetLightPreset(0);
            SelectMode(0);
            UpdateStatus();

            surface.MouseDown += OnMouseDown;
            surface.MouseUp += OnMouseUp;
            surface.LostMouseCapture += delegate { dragMode = DragMode.None; };
            surface.MouseMove += OnMouseMove;
            surface.MouseWheel += delegate(object sender, MouseWheelEventArgs e)
            {
                distance = Math.Max(0.15, Math.Min(100, distance * Math.Exp(-e.Delta * 0.001)));
                UpdateCamera(); e.Handled = true;
            };
            AddHandler(Keyboard.PreviewKeyDownEvent, new KeyEventHandler(OnPreviewKeyDown), true);
            surface.SizeChanged += delegate { UpdateWireframe(); };
            Loaded += delegate { surface.Focus(); };
            UpdateCamera();
        }

        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            surface.Focus();
            ModifierKeys modifiers = Keyboard.Modifiers;
            dragMode = DragMode.None;
            snapOrbit = false;
            if ((modifiers & ModifierKeys.Shift) != 0 && e.ChangedButton == MouseButton.Right)
                dragMode = DragMode.Light;
            else if ((modifiers & (ModifierKeys.Control | ModifierKeys.Alt)) == (ModifierKeys.Control | ModifierKeys.Alt)
                && e.ChangedButton == MouseButton.Left)
                dragMode = DragMode.Pan;
            else if ((modifiers & ModifierKeys.Alt) != 0)
            {
                if (e.ChangedButton == MouseButton.Left) { dragMode = DragMode.Orbit; snapOrbit = (modifiers & ModifierKeys.Shift) != 0; }
                if (e.ChangedButton == MouseButton.Middle) dragMode = DragMode.Pan;
                if (e.ChangedButton == MouseButton.Right) dragMode = DragMode.Zoom;
            }
            if (dragMode == DragMode.None) return;
            previous = e.GetPosition(surface);
            surface.CaptureMouse();
            e.Handled = true;
        }

        private void OnMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (dragMode == DragMode.None) return;
            if (dragMode == DragMode.Orbit && snapOrbit)
            {
                double step = Math.PI / 2;
                yaw = Math.Round(yaw / step) * step;
                pitch = Math.Max(-Math.PI / 2, Math.Min(Math.PI / 2, Math.Round(pitch / step) * step));
                UpdateCamera();
            }
            else UpdateWireframe();
            dragMode = DragMode.None;
            surface.ReleaseMouseCapture();
            e.Handled = true;
        }

        private void OnMouseMove(object sender, MouseEventArgs e)
        {
            if (dragMode == DragMode.None) return;
            Point current = e.GetPosition(surface);
            double dx = current.X - previous.X, dy = current.Y - previous.Y;
            previous = current;
            if (dragMode == DragMode.Pan)
            {
                Vector3D forward = camera.LookDirection; forward.Normalize();
                Vector3D right = Vector3D.CrossProduct(forward, camera.UpDirection); right.Normalize();
                Vector3D up = Vector3D.CrossProduct(right, forward);
                center += (-right * dx + up * dy) * (distance * 0.0015);
            }
            else if (dragMode == DragMode.Orbit)
            { yaw -= dx * 0.01; pitch = Math.Max(-1.5, Math.Min(1.5, pitch + dy * 0.01)); }
            else if (dragMode == DragMode.Zoom)
                distance = Math.Max(0.15, Math.Min(100, distance * Math.Exp((dy + dx * 0.25) * 0.01)));
            else if (dragMode == DragMode.Light)
            {
                RotateLight(dx * 0.012);
                selectedLight = -1;
                lightButton.Content = "灯光 · 自定义  ▾";
            }
            if (dragMode != DragMode.Light) UpdateCamera(false);
            e.Handled = true;
        }

        private void OnPreviewKeyDown(object sender, KeyEventArgs e)
        {
            Key key = e.Key == Key.System ? e.SystemKey : e.Key;
            if (key == Key.F && Keyboard.Modifiers == ModifierKeys.None)
            { Reset(); e.Handled = true; }
            else if (IsWireframeShortcut(e.Key, e.SystemKey, Keyboard.Modifiers) && wireToggle.IsEnabled)
            { wireToggle.IsChecked = wireToggle.IsChecked != true; e.Handled = true; }
        }

        internal static bool IsWireframeShortcut(Key key, Key systemKey, ModifierKeys modifiers)
        {
            Key actual = key == Key.System ? systemKey : key;
            return actual == Key.W && (modifiers & ModifierKeys.Alt) != 0;
        }

        private void Reset() { yaw = 0.7; pitch = 0.35; distance = 4.5; center = new Point3D(); UpdateCamera(); }
        private void UpdateCamera(bool updateWireframe = true)
        {
            var offset = new Vector3D(Math.Cos(pitch) * Math.Sin(yaw), Math.Sin(pitch), Math.Cos(pitch) * Math.Cos(yaw)) * distance;
            camera.Position = center + offset;
            camera.LookDirection = -offset;
            camera.UpDirection = new Vector3D(0, 1, 0);
            if (updateWireframe) UpdateWireframe();
        }

        internal void ShowModel(ModelResult result)
        {
            materialSlots.Clear();
            var display = new Model3DGroup { Transform = result.Model.Transform };
            int appearanceIndex = 0;
            foreach (Model3D child in result.Model.Children)
            {
                var source = child as GeometryModel3D;
                if (source == null) continue;
                MeshAppearance appearance = appearanceIndex < result.Appearances.Count ? result.Appearances[appearanceIndex] : null;
                appearanceIndex++;
                var copy = new GeometryModel3D(source.Geometry, source.Material) { BackMaterial = source.BackMaterial };
                display.Children.Add(copy);
                materialSlots.Add(new MaterialSlot(copy, source.Material, source.BackMaterial, appearance));
            }
            visual.Content = display;
            wireframe.SetLines(result.WirePoints);
            wireToggle.IsEnabled = result.WirePoints != null;
            wireToggle.ToolTip = result.WirePoints == null
                ? "模型超过 120,000 个三角面，为保证预览性能已停用线框。"
                : "在当前显示模式上叠加网格线框（Alt+W）";
            if (result.WirePoints == null) wireToggle.IsChecked = false;
            else if (wireToggle.IsChecked == true) { wireframe.IsEnabled = true; UpdateWireframe(); }

            meshCount = result.Meshes;
            metalnessChannels = result.MetalnessChannels;
            roughnessChannels = result.RoughnessChannels;
            baseStatus = String.Format("{0:N0} 个网格  ·  {1:N0} 个三角面", result.Meshes, result.Triangles);
            if (result.MissingTextures > 0) baseStatus += "  ·  " + result.MissingTextures + " 个纹理使用回退值";
            status.Foreground = TextBrush;
            ApplyMaterialMode(selectedMode);
            Reset();
            UpdateStatus();
        }

        internal void SetMaterialMode(int index) { SelectMode(index); }
        internal void SetLightPreset(int index)
        {
            if (index < 0 || index >= LightDirections.Length) return;
            selectedLight = index;
            string[] names = { "左前上", "右前上", "左后上", "右后上", "正面", "顶部" };
            lightButton.Content = "灯光 · " + names[index] + "  ▾";
            ApplyLightPreset(index);
        }
        internal void SetWireframe(bool enabled) { if (wireToggle.IsEnabled) wireToggle.IsChecked = enabled; }
        internal int WireEdgeCount { get { return wireframe.EdgeCount; } }

        private void SelectMode(int index)
        {
            if (index < 0 || index >= ModeNames.Length) return;
            selectedMode = index;
            for (int i = 0; i < modeButtons.Count; i++)
            {
                modeButtons[i].IsChecked = i == index;
                RefreshToggle(modeButtons[i]);
            }
            ApplyMaterialMode(index);
            UpdateStatus();
        }

        private void ApplyMaterialMode(int index)
        {
            Material white = index == 1 ? CreateInspectionMaterial(Color.FromRgb(218, 222, 230), Color.FromRgb(150, 155, 165), 45) : null;
            foreach (var slot in materialSlots)
            {
                Material material = slot.Original;
                if (index == 1) material = white;
                if (index == 2) material = slot.DiffuseView ?? (slot.DiffuseView = CreateUnlitMaterial(slot.Diffuse));
                if (index == 3) material = slot.MetalnessView ?? (slot.MetalnessView = CreateUnlitMaterial(slot.Metalness));
                if (index == 4) material = slot.RoughnessView ?? (slot.RoughnessView = CreateUnlitMaterial(slot.Roughness));
                slot.Model.Material = material;
                slot.Model.BackMaterial = material;
            }
        }

        private void UpdateStatus()
        {
            string suffix = "  ·  " + ModeNames[selectedMode];
            status.Foreground = TextBrush;
            if (selectedMode == 3 && metalnessChannels == 0)
            { suffix += "通道缺失，显示默认值 0"; status.Foreground = WarningBrush; }
            else if (selectedMode == 3 && metalnessChannels < meshCount)
                suffix += String.Format("：{0}/{1} 个网格含数据", metalnessChannels, meshCount);
            if (selectedMode == 4 && roughnessChannels == 0)
            { suffix += "通道缺失，显示默认值 0.5"; status.Foreground = WarningBrush; }
            else if (selectedMode == 4 && roughnessChannels < meshCount)
                suffix += String.Format("：{0}/{1} 个网格含数据", roughnessChannels, meshCount);
            if (wireToggle.IsChecked == true) suffix += "  ·  线框已开启";
            status.Text = baseStatus + suffix;
        }

        private static Material CreateUnlitMaterial(Brush brush)
        {
            var material = new EmissiveMaterial(brush);
            material.Freeze();
            return material;
        }

        private static Material CreateInspectionMaterial(Color diffuse, Color specular, double power)
        {
            var material = new MaterialGroup();
            material.Children.Add(new DiffuseMaterial(new SolidColorBrush(diffuse)));
            material.Children.Add(new SpecularMaterial(new SolidColorBrush(specular), power));
            material.Freeze();
            return material;
        }

        private void ApplyLightPreset(int index)
        {
            if (index < 0 || index >= LightDirections.Length) return;
            Vector3D direction = LightDirections[index];
            direction.Normalize();
            keyLight.Direction = direction;
            fillLight.Direction = new Vector3D(-direction.X, -0.15, -direction.Z);
        }

        private void RotateLight(double angle)
        {
            Vector3D direction = keyLight.Direction;
            double sin = Math.Sin(angle), cos = Math.Cos(angle);
            keyLight.Direction = new Vector3D(direction.X * cos - direction.Z * sin,
                direction.Y, direction.X * sin + direction.Z * cos);
            direction = keyLight.Direction;
            fillLight.Direction = new Vector3D(-direction.X, -0.15, -direction.Z);
        }

        private void UpdateWireframe() { wireframe.Update(camera, viewport.ActualHeight); }
        internal void ShowError(string message)
        {
            baseStatus = message;
            status.Text = message;
            status.Foreground = WarningBrush;
        }
        internal void Release()
        {
            visual.Content = null;
            wireframe.SetLines(null);
            materialSlots.Clear();
            if (Mouse.Captured != null && IsAncestorOf(Mouse.Captured as DependencyObject)) Mouse.Capture(null);
        }

        private static ToggleButton CreateToggleButton(string text, double width)
        {
            var button = new ToggleButton
            {
                Content = text, Width = width, Height = 30, Margin = new Thickness(1, 0, 1, 0),
                Padding = new Thickness(7, 3, 7, 3), Foreground = MutedBrush,
                Background = Brushes.Transparent, BorderBrush = Brushes.Transparent,
                BorderThickness = new Thickness(1), FontSize = 12, Focusable = false, Cursor = Cursors.Hand,
                Template = CreateFlatTemplate(typeof(ToggleButton))
            };
            button.MouseEnter += delegate { if (button.IsChecked != true) button.Background = HoverBrush; };
            button.MouseLeave += delegate { RefreshToggle(button); };
            return button;
        }

        private static Button CreateActionButton(string text, double width)
        {
            var button = new Button
            {
                Content = text, Width = width, Height = 32, Padding = new Thickness(8, 3, 8, 3),
                Foreground = TextBrush, Background = PanelRaisedBrush, BorderBrush = BorderBrush,
                BorderThickness = new Thickness(1), FontSize = 12, Focusable = false, Cursor = Cursors.Hand,
                Template = CreateFlatTemplate(typeof(Button))
            };
            button.MouseEnter += delegate { button.Background = HoverBrush; };
            button.MouseLeave += delegate { button.Background = PanelRaisedBrush; };
            return button;
        }

        private static void RefreshToggle(ToggleButton button)
        {
            bool selected = button.IsChecked == true;
            button.Background = selected ? AccentBrush : Brushes.Transparent;
            button.BorderBrush = selected ? AccentBrush : Brushes.Transparent;
            button.Foreground = selected ? Brushes.White : MutedBrush;
            button.FontWeight = selected ? FontWeights.SemiBold : FontWeights.Normal;
        }

        private static string GetModeToolTip(int mode)
        {
            if (mode == 0) return "显示导入的材质和纹理";
            if (mode == 1) return "使用统一白色检查模型形体";
            if (mode == 2) return "无光照显示漫反射 / Base Color 通道";
            if (mode == 3) return "无光照灰度显示金属度通道";
            return "无光照灰度显示粗糙度通道";
        }

        private static SolidColorBrush FrozenBrush(Color color)
        {
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }

        private static ControlTemplate CreateFlatTemplate(Type targetType)
        {
            var template = new ControlTemplate(targetType);
            var border = new FrameworkElementFactory(typeof(Border));
            border.SetValue(Border.CornerRadiusProperty, new CornerRadius(5));
            border.SetBinding(Border.BackgroundProperty, new Binding("Background") { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent) });
            border.SetBinding(Border.BorderBrushProperty, new Binding("BorderBrush") { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent) });
            border.SetBinding(Border.BorderThicknessProperty, new Binding("BorderThickness") { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent) });
            border.SetBinding(Border.PaddingProperty, new Binding("Padding") { RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent) });
            var content = new FrameworkElementFactory(typeof(ContentPresenter));
            content.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            content.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            content.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
            border.AppendChild(content);
            template.VisualTree = border;
            return template;
        }

        private enum DragMode { None, Orbit, Pan, Zoom, Light }

        private sealed class MaterialSlot
        {
            internal readonly GeometryModel3D Model;
            internal readonly Material Original;
            internal readonly Material OriginalBack;
            internal readonly Brush Diffuse;
            internal readonly Brush Metalness;
            internal readonly Brush Roughness;
            internal Material DiffuseView, MetalnessView, RoughnessView;

            internal MaterialSlot(GeometryModel3D model, Material original, Material originalBack, MeshAppearance appearance)
            {
                Model = model; Original = original; OriginalBack = originalBack;
                Diffuse = appearance == null ? Brushes.Gray : appearance.Diffuse;
                Metalness = appearance == null ? Brushes.Black : appearance.Metalness;
                Roughness = appearance == null ? Brushes.Gray : appearance.Roughness;
            }
        }

        private sealed class WireframeVisual : ModelVisual3D
        {
            private readonly GeometryModel3D linesModel;
            private Point3DCollection lines;
            private bool enabled;
            internal int EdgeCount { get { return lines == null ? 0 : lines.Count / 2; } }
            internal bool IsEnabled
            {
                get { return enabled; }
                set { enabled = value; if (!value) linesModel.Geometry = null; }
            }
            internal WireframeVisual()
            {
                var brush = new SolidColorBrush(Color.FromRgb(76, 190, 240)) { Opacity = 0.78 };
                var material = new EmissiveMaterial(brush);
                material.Freeze();
                linesModel = new GeometryModel3D { Material = material, BackMaterial = material };
                Content = linesModel;
            }
            internal void SetLines(Point3DCollection value)
            {
                lines = value;
                linesModel.Geometry = null;
            }
            internal void Update(PerspectiveCamera activeCamera, double viewportHeight)
            {
                if (lines == null || !enabled || viewportHeight < 1) return;
                var positions = new Point3DCollection(lines.Count * 2);
                var indices = new Int32Collection(lines.Count * 3);
                double scale = 2 * Math.Tan(activeCamera.FieldOfView * Math.PI / 360) / viewportHeight;
                for (int i = 0; i + 1 < lines.Count; i += 2)
                {
                    Point3D p0 = lines[i], p1 = lines[i + 1];
                    Point3D midpoint = new Point3D((p0.X + p1.X) / 2, (p0.Y + p1.Y) / 2, (p0.Z + p1.Z) / 2);
                    Vector3D towardCamera = activeCamera.Position - midpoint;
                    Vector3D side = Vector3D.CrossProduct(p1 - p0, towardCamera);
                    if (side.LengthSquared < 1e-16) side = Vector3D.CrossProduct(p1 - p0, activeCamera.UpDirection);
                    if (side.LengthSquared < 1e-16) continue;
                    side.Normalize(); towardCamera.Normalize();
                    double halfWidth = (activeCamera.Position - midpoint).Length * scale * 0.48;
                    side *= halfWidth;
                    Vector3D lift = towardCamera * (halfWidth * 0.75);
                    int first = positions.Count;
                    positions.Add(p0 - side + lift); positions.Add(p0 + side + lift);
                    positions.Add(p1 - side + lift); positions.Add(p1 + side + lift);
                    indices.Add(first); indices.Add(first + 2); indices.Add(first + 1);
                    indices.Add(first + 1); indices.Add(first + 2); indices.Add(first + 3);
                }
                var mesh = new MeshGeometry3D { Positions = positions, TriangleIndices = indices };
                mesh.Freeze();
                linesModel.Geometry = mesh;
            }
        }
    }
}
