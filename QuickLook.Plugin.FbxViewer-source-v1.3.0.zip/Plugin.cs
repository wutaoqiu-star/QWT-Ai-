// SPDX-License-Identifier: GPL-3.0-or-later
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using QuickLook.Common.Plugin;

namespace QuickLook.Plugin.FbxViewer
{
    public sealed class Plugin : IViewer
    {
        private CancellationTokenSource pending;
        private ModelView view;
        public int Priority { get { return 10; } }
        public void Init() { }
        public bool CanHandle(string path)
        {
            return !String.IsNullOrEmpty(path) && File.Exists(path) &&
                String.Equals(Path.GetExtension(path), ".fbx", StringComparison.OrdinalIgnoreCase);
        }
        public void Prepare(string path, ContextObject context)
        {
            context.PreferredSize = new Size(1080, 720);
            context.FullWindowDragging = false;
        }
        public async void View(string path, ContextObject context)
        {
            Cleanup();
            var source = new CancellationTokenSource();
            pending = source;
            var token = source.Token;
            var target = new ModelView();
            view = target;
            context.ViewerContent = target;
            context.Title = Path.GetFileName(path);
            context.IsBusy = true;
            try
            {
                var result = await Task.Run(() => ModelLoader.Load(path, token), token);
                if (!token.IsCancellationRequested) target.ShowModel(result);
            }
            catch (OperationCanceledException) { }
            catch (Exception error)
            {
                if (!token.IsCancellationRequested)
                    target.ShowError("无法预览此 FBX。\n" + error.Message);
            }
            finally
            {
                if (!token.IsCancellationRequested) context.IsBusy = false;
                if (ReferenceEquals(pending, source)) pending = null;
                source.Dispose();
            }
        }
        public void Cleanup()
        {
            if (pending != null) { pending.Cancel(); pending = null; }
            if (view != null) { view.Release(); view = null; }
        }
    }
}
